package com.example.fabel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FabelApplication {

	public static void main(String[] args) {
		SpringApplication.run(FabelApplication.class, args);
	}

}
